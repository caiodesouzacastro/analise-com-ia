# Erros comuns ao usar IA em análise qualitativa e quantitativa

Use esta lista na conferência. Cada item diz como o erro aparece e a solução.

- Categoria forçada: todo trecho ganha um código, inclusive o que não fala do tema. Solução: regra explícita de SEM CÓDIGO no prompt e conferência dos trechos codificados com uma frase só.
- Citação inventada ou recortada: frase parecida com a fala, ou cortada de um jeito que muda o sentido. Solução: exigir citação literal entre aspas e conferir letra por letra.
- Ironia lida ao pé da letra: "adorei" vira avaliação positiva. Solução: marcar DÚVIDA e revisar à mão as falas com ironia.
- Contexto perdido: "essa sim funcionou" citado sem dizer qual formação. Solução: ler cada trecho com o anterior; incluir o contexto na citação.
- Voz que destoa apagada: o resumo fica com a média e some quem tem experiência diferente. Solução: pedir separadamente o que cada entrevistado diz de único.
- Fala genérica vira evidência: "formação é sempre boa" usado como avaliação. Solução: tratar falas vagas como SEM CÓDIGO ou DÚVIDA.
- Contagem vira importância: quadro com número de trechos por categoria. Solução: reportar frequência só como descrição, nunca como peso.
- Unidade de contagem errada: soma por escola tratada como número de pessoas. Solução: dizer a unidade antes e conferir contra um total publicado.
- Arquivo ou variável inventados: código para um arquivo que não existe na base pública. Solução: colar a lista de colunas e o dicionário antes de pedir o código.
- Rótulo errado no resultado: a ressalva fica no chat e o código imprime "Total de docentes". Solução: ler o print final do código e corrigir o rótulo.
- Dado pessoal na ferramenta: transcrição com nome e escola colada num chat aberto. Solução: anonimizar antes; usar ferramenta institucional quando houver.
