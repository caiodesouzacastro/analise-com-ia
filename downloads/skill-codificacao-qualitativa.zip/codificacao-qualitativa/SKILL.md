---
name: codificacao-qualitativa
description: Codifica trechos de entrevistas, grupos focais ou respostas abertas com um livro de códigos fechado, exigindo citação literal para cada código, marcando SEM CÓDIGO e DÚVIDA, e listando as dúvidas sobre o próprio livro de códigos. Use quando pedirem codificação qualitativa, análise de entrevistas com livro de códigos, teste de um livro de códigos ou conferência de citações de uma codificação.
---

# Codificação qualitativa com livro fechado

Esta skill aplica um livro de códigos a trechos de texto de um jeito que outra pessoa consegue conferir: cada código aponta para uma frase exata do trecho. O objetivo não é codificar rápido; é chegar a uma codificação em que nenhum código fica sem prova no texto.

## Regras que nunca mudam

1. Use só os códigos do livro de códigos fornecido. Não crie códigos durante a codificação. Se achar que falta um, registre na seção de dúvidas.
2. Um trecho pode ter mais de um código ou nenhum. Quando nenhum couber, marque SEM CÓDIGO.
3. Para cada código aplicado, copie entre aspas a frase exata do trecho que o justifica. Não parafraseie, não corrija o português e não junte frases de trechos ou de pessoas diferentes.
4. Tom: positivo, negativo, neutro ou misto sobre o tema da análise. Marque DÚVIDA quando não der para saber.
5. Não resuma e não interprete além do texto. Ironia, fala ambígua e fala que depende da anterior vão para DÚVIDA, com a razão na observação.
6. Fala genérica, que não diz nada específico sobre o tema, fica SEM CÓDIGO ou DÚVIDA. Ela não serve de evidência.
7. Frequência não é importância. Se contar trechos ou pessoas, apresente a contagem só como descrição.

## Quem decide o quê

Você faz o trabalho mecânico e deixa o julgamento visível.
- Equipe: fecha a pergunta e o livro de códigos, confere as citações e revisa os trechos em DÚVIDA e SEM CÓDIGO.
- Quem conhece o tema: decide os casos de fronteira do livro de códigos e confere se as vozes que destoam chegaram à síntese.
Ao fim de cada entrega, diga em uma linha o que a equipe precisa conferir.

## Etapas

Pare ao fim de cada etapa e mostre o resultado para o usuário conferir antes de seguir.

### 1. Receber o material
Peça a pergunta da análise, o livro de códigos e os trechos com identificador (P1-01, P1-02...). Se os trechos tiverem nome de pessoa, de escola ou de cidade, avise e peça a versão anonimizada antes de seguir. Se não houver livro de códigos, use o modelo de `references/livro-de-codigos-modelo.md` para ajudar a equipe a escrever um, sem fechá-lo por ela.

### 2. Testar o livro de códigos
Se o usuário pedir, ou se o livro ainda não foi testado, aplique o livro a uma amostra de 5 a 10 trechos e liste as dúvidas sobre as definições: o que não fica claro se entra, códigos que se sobrepõem, situações que nenhum código cobre. Não corrija o livro; aponte e pergunte.

### 3. Codificar
Devolva uma tabela com uma linha por código aplicado: ID do trecho, código, citação literal, tom e observação. Trechos SEM CÓDIGO também aparecem, com a razão na observação.

### 4. Conferir as citações
Se você puder executar código, procure cada citação, como texto exato, dentro do trecho correspondente, e marque as que não aparecem letra por letra. Se não puder, compare à mão e diga que a conferência foi manual. Corrija ou retire toda citação que não estiver no trecho.

### 5. Se pedirem resumo ou síntese
Antes de qualquer resumo, liste para cada entrevistado, separadamente, o que só ele diz, com citação literal e ID do trecho. Não confie numa lista geral de falas que destoam: num teste, a voz que mais destoava ficou de fora mesmo com pedido explícito. Cada afirmação do resumo aponta para os IDs dos trechos. Marque como [inferência] o que não estiver nos trechos.

### 6. Dúvidas sobre o livro
Liste as dúvidas que surgiram durante a codificação sobre o próprio livro de códigos. Elas costumam ser o resultado mais útil: mostram onde as definições estão frouxas antes da análise.

## Ao terminar qualquer entrega

Feche com uma seção curta "Para conferir": os trechos em DÚVIDA e SEM CÓDIGO, as citações que valem conferir letra por letra, as dúvidas sobre o livro de códigos e o que pede revisão de quem conhece o tema. Use `references/checklist.md` e `references/erros-comuns.md`.

## Dados

Se aparecerem dados pessoais, avise e sugira anonimizar antes de seguir.
