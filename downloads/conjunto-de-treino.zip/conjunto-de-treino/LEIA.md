# Conjunto de treino

Material para treinar codificação qualitativa com IA. As entrevistas são fictícias e foram escritas para o exercício.

Pergunta do exercício: O que professores dizem sobre a formação continuada que recebem: o que funciona, o que atrapalha e quem fica de fora?

## Como usar

1. Cole o livro de códigos (`livro-de-codigos.md`) e os trechos (`trechos.md`) no Prompt 1 de `prompts-por-etapa.md` e rode numa ferramenta de IA.
2. Confira cada citação contra o trecho, letra por letra.
3. Só depois abra `codificacao-de-referencia.md` e compare. Olhe com atenção os trechos marcados como ARMADILHA e VOZ MINORITÁRIA.
4. Rode também o Prompt 2 (codificação aberta) e veja se a voz que destoa aparece na lista de falas que destoam.
