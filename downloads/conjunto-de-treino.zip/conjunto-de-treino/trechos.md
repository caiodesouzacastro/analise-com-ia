# Trechos (fictícios)

Professores: P1, anos iniciais, rede municipal urbana. P2, matemática, anos finais, rede estadual. P3, escola do campo com turma multisseriada. P4, língua portuguesa, ensino médio. P5, ciências, anos finais, rede municipal.

P1-01 · A formação de alfabetização do ano passado foi a primeira que eu saí usando no dia seguinte. Trouxeram atividade pronta, a gente testou ali mesmo com as fichas de leitura.
P1-02 · O problema é que acontece no intervalo do almoço. A gente come correndo e entra na sala de formação.
P1-03 · A coordenadora passou na minha sala duas semanas depois para ver a atividade. Isso fez diferença, porque eu tinha invertido a ordem das etapas e ela me mostrou.
P1-04 · Ninguém pergunta para a gente o que a gente precisa. Chega o calendário pronto da secretaria.
P2-01 · Adorei a formação de sábado. Nada melhor do que passar a única folga da semana ouvindo alguém ler slide em voz alta.
P2-02 · A plataforma online até tem coisa boa, mas é vídeo atrás de vídeo, e o certificado só sai se você assistir até o fim. Eu deixo rodando e corrijo prova.
P2-03 · Para a progressão contam as horas, não o que você aprendeu. Então todo mundo faz curso de qualquer coisa para fechar a carga.
P2-04 · Esse ano trocaram o diretor, e a escola está um caos com a violência na porta. Teve semana que a gente nem conseguiu dar aula.
P3-01 · Tudo o que vem de formação é pensado para turma de um ano só. Eu tenho do primeiro ao quinto na mesma sala e ninguém nunca falou disso.
P3-02 · Para ir à formação na cidade eu perco o dia inteiro, são duas horas de estrada, e a escola fica fechada porque não tem quem me substitua.
P3-03 · A gente pediu uma vez para a formação vir até aqui, juntando as três escolas do campo. Disseram que iam ver.
P3-04 · Quando teve a formação online eu consegui fazer, mas a internet aqui cai toda hora, então fiz pelo celular, à noite.
P4-01 · A da rede, no segundo semestre, eu achei boa. Já a da editora do livro didático foi muito ruim, era propaganda do material.
P4-02 · Essa sim funcionou: tinha um formador que acompanhava a gente o semestre inteiro e mandava devolutiva das aulas gravadas.
P4-03 · Eu gostaria de escolher a formação pela minha área. Português tem uma demanda de leitura que a formação geral não pega.
P4-04 · O certificado entra na pontuação da remoção, então isso ajuda quem quer mudar de escola.
P5-01 · O que mais me ajudou foi o grupo de estudos entre os professores da escola, toda quarta, uma hora. Não tem formador, a gente leva o problema da sala.
P5-02 · Depois da formação de avaliação ninguém voltou para saber se a gente aplicou. Ficou a apostila na gaveta.
P5-03 · Formação é sempre boa, né. A gente sempre aprende alguma coisa.
P5-04 · Eu fiz a especialização por conta própria, paguei do meu bolso, e não contou nada na carreira porque não estava na lista da secretaria.
