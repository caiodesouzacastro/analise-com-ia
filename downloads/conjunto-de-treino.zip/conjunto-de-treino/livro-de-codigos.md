# Livro de códigos

REL · Relevância para a prática: a formação se conecta, ou não, com o que o professor faz em sala.
TEM · Tempo e condições: horário, deslocamento, substituição, carga.
FOR · Formato: presencial, online, grupo de estudos, acompanhamento por formador.
ACO · Acompanhamento depois: alguém volta para ver se a formação foi aplicada, dá devolutiva.
ESC · Escolha e participação: o professor participa, ou não, da definição do que fazer.
REC · Reconhecimento e carreira: certificado, horas, progressão, pontuação.
Regras: um trecho pode ter mais de um código ou nenhum. Trecho sem relação com formação fica SEM CÓDIGO.
