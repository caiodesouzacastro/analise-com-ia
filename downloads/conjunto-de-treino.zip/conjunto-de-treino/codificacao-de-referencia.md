# Codificação de referência

Use depois de codificar, para comparar.

| ID | Código | Tom | Observação |
|---|---|---|---|
| P1-01 | REL, FOR | positivo |  |
| P1-02 | TEM | negativo |  |
| P1-03 | ACO | positivo |  |
| P1-04 | ESC | negativo |  |
| P2-01 | TEM, FOR | negativo | ARMADILHA ironia: "adorei" não é avaliação positiva |
| P2-02 | FOR, REC | negativo |  |
| P2-03 | REC | negativo |  |
| P2-04 | SEM CÓDIGO |  | ARMADILHA fora do escopo: fala de gestão e violência, não de formação |
| P3-01 | REL | negativo | VOZ MINORITÁRIA: turma multisseriada |
| P3-02 | TEM | negativo | VOZ MINORITÁRIA: deslocamento e escola fechada |
| P3-03 | ESC, FOR | negativo | VOZ MINORITÁRIA |
| P3-04 | FOR, TEM | DÚVIDA (misto: conseguiu fazer, em condição ruim) |  |
| P4-01 | FOR, REL | misto (rede positiva, editora negativa) |  |
| P4-02 | ACO, FOR | positivo | ARMADILHA contexto: "essa" é a formação da rede, não a da editora |
| P4-03 | ESC, REL | negativo |  |
| P4-04 | REC | positivo |  |
| P5-01 | FOR, REL | positivo |  |
| P5-02 | ACO | negativo |  |
| P5-03 | SEM CÓDIGO ou DÚVIDA |  | ARMADILHA genérico: avaliação vaga, não sustenta conclusão sobre relevância |
| P5-04 | REC | negativo |  |

## Mensagens-chave para comparação

A formação é vista como útil quando traz atividade aplicável e alguém acompanha depois (P1-01, P1-03, P4-02, P5-01); sem acompanhamento, fica na gaveta (P5-02).

Tempo e horário são a queixa mais frequente (P1-02, P2-01, P3-02, P3-04).

Reconhecer só a carga horária leva a curso feito pelo certificado (P2-02, P2-03, P5-04), com uma exceção positiva na remoção (P4-04).

Os professores não participam da escolha da formação (P1-04, P3-03, P4-03).

Quem destoa: a professora da escola do campo não se vê na formação e enfrenta deslocamento e falta de substituição (P3-01 a P3-03). Um resumo que diga "os professores avaliam a formação como relevante" apagou essa voz.

P2-04 está fora do escopo e P5-03 não sustenta nenhuma conclusão.
